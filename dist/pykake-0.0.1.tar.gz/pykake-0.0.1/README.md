# pykake

A minimal functional package to be used as a model for other python packages.